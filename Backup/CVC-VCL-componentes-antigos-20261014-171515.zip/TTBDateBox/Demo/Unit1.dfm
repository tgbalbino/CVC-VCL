object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 299
  ClientWidth = 635
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object DateBox1: TDateBox
    Left = 8
    Top = 24
    Width = 321
    Height = 73
    Caption = ' Campo Data '
    TabOrder = 0
    GDB = Firebird
    QuotedDate = False
  end
end
