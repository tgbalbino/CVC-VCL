unit GroupBox2;

interface

uses
  System.SysUtils, System.Classes, Vcl.Controls, Vcl.StdCtrls, JvToolEdit;

type
  TDateBox = class(TGroupBox)
  private
    EdDateStart: TJvDateEdit;
    EdDateEnd: TJvDateEdit;
    CbIgnore: TCheckBox;

    procedure CbIgnoreClick(Sender: TObject);
    { Private declarations }
  protected
    { Protected declarations }
  public
    constructor Create(AOwner: TComponent); override;
    { Public declarations }
  published
    { Published declarations }
  end;

procedure Register;

implementation

procedure Register;
begin
  RegisterComponents('Samples', [TDateBox]);
end;

{ TDateBox }

procedure TDateBox.CbIgnoreClick(Sender: TObject);
begin
  EdDateStart.Enabled := CbIgnore.Checked;
  EdDateEnd.Enabled   := CbIgnore.Checked;
end;

constructor TDateBox.Create(AOwner: TComponent);
begin
  inherited;

  EdDateStart := TJvDateEdit.Create(Self);
  EdDateEnd   := TJvDateEdit.Create(Self);
  EdDateStart.Left := 20;

    EdDateStart.Left := 90;

  CbIgnore := TCheckBox.Create(Self);
  CbIgnore.Checked := True;
  CbIgnore.OnClick := CbIgnoreClick;
end;

end.
