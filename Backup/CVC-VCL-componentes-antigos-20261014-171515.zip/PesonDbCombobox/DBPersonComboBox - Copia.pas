unit DBPersonComboBox;

interface

uses
  System.Classes, Vcl.DBCtrls, Data.DB;

type
  TDBPersonComboBox = class(TDBComboBox)
  private
    FValues: TStringList;
    FIsUpdating: Boolean; // Para evitar loops durante a atualiza��o
    FLastItemIndex: Integer; // Para armazenar o �ltimo �ndice selecionado
    procedure SetValues(const Value: TStringList);
    procedure UpdateFieldValue;
  protected
    procedure Click; override;
    procedure Change; override;
    procedure Notification(AComponent: TComponent; Operation: TOperation); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
  published
    property Values: TStringList read FValues write SetValues;
  end;

procedure Register;

implementation

procedure Register;
begin
  RegisterComponents('Samples', [TDBPersonComboBox]);
end;

{ TDBPersonComboBox }

constructor TDBPersonComboBox.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FValues := TStringList.Create;
  FIsUpdating := False;
  FLastItemIndex := -1;
end;

destructor TDBPersonComboBox.Destroy;
begin
  FValues.Free;
  inherited Destroy;
end;

procedure TDBPersonComboBox.SetValues(const Value: TStringList);
begin
  FValues.Assign(Value);
end;

procedure TDBPersonComboBox.Click;
begin
  inherited Click;
  UpdateFieldValue;
end;

procedure TDBPersonComboBox.Change;
begin
  if not FIsUpdating then
    FLastItemIndex := ItemIndex;
  inherited Change;
end;

procedure TDBPersonComboBox.UpdateFieldValue;
var
  Field: TField;
begin
  if FIsUpdating then
    Exit;

  if (ItemIndex >= 0) and (ItemIndex < FValues.Count) and (DataSource <> nil) then
  begin
    Field := DataSource.DataSet.FieldByName(DataField);
    if (Field <> nil) and not Field.ReadOnly then
    begin
      FIsUpdating := True;
      try
        // Atualiza o valor do campo no dataset com o valor correspondente do FValues
        Field.AsString := FValues[ItemIndex];

        // Sincroniza o �ndice selecionado e o texto exibido
        FLastItemIndex := ItemIndex;
        Text := Items[ItemIndex];
      finally
        FIsUpdating := False;
      end;
    end;
  end;
end;

procedure TDBPersonComboBox.Notification(AComponent: TComponent; Operation: TOperation);
begin
  inherited Notification(AComponent, Operation);
  // Remove refer�ncias a componentes desconectados
  if (Operation = opRemove) and (AComponent = DataSource) then
    DataSource := nil;
end;

end.

