unit DBLookupEditSettings;

interface

implementation

end.
